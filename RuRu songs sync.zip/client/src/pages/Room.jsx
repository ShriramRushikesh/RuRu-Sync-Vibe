import React, { useEffect, useState } from 'react';
import { useLocation, useParams, useNavigate } from 'react-router-dom';
import { io } from 'socket.io-client';
import { useRoomStore } from '../store/useRoomStore';
import RoomPlayer from '../components/RoomPlayer';
import Chat from '../components/Chat';
import CoupleFeatures from '../components/CoupleFeatures';
import LoveNotes from '../components/LoveNotes';
import TouchSync from '../components/TouchSync';
import Logo from '../components/Logo';
import MusicSearch from '../components/MusicSearch';
import { Share2, Users } from 'lucide-react';

export default function Room() {
  const { id } = useParams();
  const { state } = useLocation();
  const navigate = useNavigate();
  const { setSocket, setRoom, room, moodMode, setMoodMode, addChatMessage, addLoveNote, addVirtualGift, addEmoji, setTyping, updateRoomQueue, updateRoomFavorites, updateCurrentSong, updateSongProgress } = useRoomStore();
  const [isShaking, setIsShaking] = useState(false);

  useEffect(() => {
    if (!state?.username) {
      navigate('/');
      return;
    }

    const newSocket = io(import.meta.env.VITE_API_URL || 'http://localhost:5001');
    setSocket(newSocket);

    newSocket.emit('join_room', { 
      roomId: id, 
      username: state.username, 
      isHost: state.isHost,
      isCoupleMode: state.isCoupleMode 
    });

    newSocket.on('room_update', setRoom);
    newSocket.on('mood_changed', setMoodMode);
    
    newSocket.on('queue_updated', updateRoomQueue);
    newSocket.on('favorites_updated', updateRoomFavorites);
    newSocket.on('sync_player', updateCurrentSong);
    newSocket.on('sync_progress', updateSongProgress);
    
    newSocket.on('receive_message', addChatMessage);
    newSocket.on('receive_love_note', addLoveNote);
    newSocket.on('receive_gift', addVirtualGift);
    newSocket.on('receive_emoji', addEmoji);
    newSocket.on('partner_typing', (data) => setTyping(data.isTyping, data.msg));
    newSocket.on('attention_stolen', () => {
      setIsShaking(true);
      if (navigator.vibrate) navigator.vibrate([200, 100, 200]);
      setTimeout(() => setIsShaking(false), 800);
    });
    newSocket.on('error', (err) => {
      alert(err.message);
      navigate('/');
    });

    return () => newSocket.disconnect();
  }, [id, state, navigate]);

  if (!room) return <div className="min-h-screen flex items-center justify-center">Loading Vibes...</div>;

  const bgStyles = {
    normal: 'from-zinc-950 via-zinc-900 to-zinc-950 bg-gradient-to-br',
    candlelight: 'from-orange-950 via-red-950 to-zinc-950 bg-gradient-to-br',
    sunset: 'bg-sunset-animated',
    stars: 'from-blue-950 via-zinc-950 to-black bg-gradient-to-br'
  };

  return (
    <div className={`min-h-screen transition-colors duration-1000 relative ${bgStyles[moodMode]} ${isShaking ? 'animate-[shake_0.2s_ease-in-out_4]' : ''}`}>
      
      {/* Dynamic Sunset Background */}
      {moodMode === 'sunset' && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
          <div className="absolute top-[30%] left-1/2 -translate-x-1/2 w-64 h-64 bg-gradient-to-br from-yellow-300 via-orange-400 to-red-500 rounded-full blur-[60px] opacity-80 animate-pulse"></div>
          <div className="absolute bottom-0 left-0 w-full h-[45%] bg-gradient-to-t from-[#0f172a] via-[#1e1b4b]/80 to-transparent flex flex-col justify-end">
            <div className="w-full h-4 bg-orange-400/20 blur-sm animate-ripple mb-2"></div>
            <div className="w-full h-6 bg-yellow-500/10 blur-sm animate-ripple-delayed mb-4"></div>
            <div className="w-full h-8 bg-red-500/10 blur-md animate-ripple mb-8"></div>
          </div>
        </div>
      )}

      <div className="relative z-10 w-full h-full">
        <LoveNotes />
        
        <header className="p-4 border-b border-white/5 flex justify-between items-center bg-black/20 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <Logo className="h-10 w-auto text-pink-400 drop-shadow-[0_0_8px_rgba(236,72,153,0.5)]" />
            <span className="text-zinc-600 hidden sm:inline-block">|</span>
            <span className="text-sm font-medium bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent hidden sm:inline-block">
              {room.isCoupleMode ? 'Our Space 🕊️💕' : 'Vibes Room'}
            </span>
          </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-zinc-400 bg-black/30 px-3 py-1.5 rounded-full">
            <Users className="w-4 h-4" />
            <span className="text-sm font-medium">{room.users.length}{room.isCoupleMode ? '/2' : ''} Users</span>
          </div>
          <button 
            onClick={() => navigator.clipboard.writeText(window.location.href)}
            className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-full transition-all text-sm font-medium"
          >
            <Share2 className="w-4 h-4" />
            Invite Code: {id}
          </button>
        </div>
      </header>

      <main className="max-w-[1600px] mx-auto p-4 md:p-8 grid grid-cols-1 lg:grid-cols-4 gap-6 h-[calc(100vh-80px)]">
        <div className="lg:col-span-2 flex flex-col gap-6 overflow-y-auto pb-4 custom-scrollbar">
          <RoomPlayer isHost={state?.isHost} username={state?.username} />
          {room.isCoupleMode && <TouchSync />}
          {room.isCoupleMode && <CoupleFeatures username={state?.username} />}
        </div>
        <div className="h-full flex flex-col lg:col-span-1">
          <MusicSearch />
        </div>
        <div className="h-full flex flex-col bg-black/20 rounded-3xl border border-white/5 backdrop-blur-md overflow-hidden lg:col-span-1">
          <Chat username={state?.username} />
        </div>
      </main>
      </div>
    </div>
  );
}
