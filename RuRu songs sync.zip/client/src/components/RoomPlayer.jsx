import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, SkipForward, SkipBack, Volume2, Search, ListMusic, Heart as HeartIcon, Music } from 'lucide-react';
import { useRoomStore } from '../store/useRoomStore';
import ReactPlayer from 'react-player';

export default function RoomPlayer({ isHost }) {
  const { room, socket, moodMode, setMoodMode } = useRoomStore();
  const playerRef = useRef(null);
  
  // Local state for UI representation
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [activeTab, setActiveTab] = useState('player'); // player, search, queue, liked
  const [duration, setDuration] = useState(0);

  useEffect(() => {
    if (room?.currentSong) {
      if (room.currentSong.isPlaying !== isPlaying) {
        setIsPlaying(room.currentSong.isPlaying);
      }
      // If we are significantly out of sync, sync progress
      if (!isHost && playerRef.current && room.currentSong.progressMs !== undefined) {
        const currentMs = playerRef.current.getCurrentTime() * 1000;
        if (Math.abs(currentMs - room.currentSong.progressMs) > 2000) {
           playerRef.current.seekTo(room.currentSong.progressMs / 1000, 'seconds');
        }
      }
    } else {
      setIsPlaying(false);
    }
  }, [room?.currentSong, isHost]);

  // Host periodically syncs progress
  const handleProgress = (state) => {
    setProgress(state.playedSeconds * 1000);
    if (isHost && isPlaying) {
      // Sync every ~3 seconds to not spam sockets
      if (Math.floor(state.playedSeconds) % 3 === 0) {
        socket.emit('sync_progress', state.playedSeconds * 1000);
      }
    }
  };

  const handleDuration = (dur) => {
    setDuration(dur * 1000);
  };

  const togglePlay = () => {
    if (!isHost) return;
    const newState = !isPlaying;
    setIsPlaying(newState);
    if (room?.currentSong) {
      socket.emit('player_state_change', {
        ...room.currentSong,
        isPlaying: newState,
        progressMs: progress
      });
    }
  };

  const playNext = () => {
    if (!isHost) return;
    socket.emit('play_next');
  };

  const handleSongEnd = () => {
    if (isHost) {
      playNext();
    }
  };

  const formatTime = (ms) => {
    if (!ms || isNaN(ms)) return "0:00";
    const totalSeconds = Math.floor(ms / 1000);
    const m = Math.floor(totalSeconds / 60);
    const s = totalSeconds % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const playSong = (song) => {
    if (!isHost) return;
    socket.emit('player_state_change', {
      ...song,
      isPlaying: true,
      progressMs: 0
    });
  };

  const renderSongItem = (song, isQueue = false, index = 0) => (
    <div key={song.videoId + (isQueue ? `_q_${index}` : '')} className="flex items-center gap-3 p-2 hover:bg-white/5 rounded-lg group transition-colors">
      <div className="relative w-12 h-12 rounded-md overflow-hidden flex-shrink-0 cursor-pointer" onClick={() => playSong(song)}>
        <img src={song.thumbnail} alt={song.title} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
           <Play className="w-6 h-6 text-white" fill="currentColor" />
        </div>
      </div>
      <div className="flex-1 min-w-0">
         <h4 className="text-white text-sm font-semibold truncate group-hover:text-pink-400 transition-colors">{song.title}</h4>
         <p className="text-zinc-400 text-xs truncate">{song.artist}</p>
      </div>
    </div>
  );

  const currentSong = room?.currentSong;
  const hasSong = !!currentSong?.url;

  return (
    <div className="bg-black/40 rounded-3xl border border-white/10 backdrop-blur-xl p-6 relative overflow-hidden">
      
      {/* Background blur of album art */}
      <div className="absolute inset-0 bg-gradient-to-br from-zinc-800 to-zinc-900 opacity-50" />
      {hasSong && currentSong.thumbnail && (
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-20 blur-3xl"
          style={{ backgroundImage: `url(${currentSong.thumbnail})` }}
        />
      )}

      <div className="relative z-10 flex flex-col md:flex-row gap-8 items-center">
        {/* Album Art Container / Hidden Player */}
        <div className="w-48 h-48 sm:w-64 sm:h-64 rounded-2xl bg-zinc-800 shadow-2xl overflow-hidden flex-shrink-0 relative group">
          {hasSong && currentSong.thumbnail ? (
            <img src={currentSong.thumbnail} alt="thumbnail" className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-purple-800 to-pink-900 flex items-center justify-center">
               <Music className="w-24 h-24 text-white/30" />
            </div>
          )}
          
          {/* Heartbeat pulse overlay */}
          {isPlaying && (
            <div className="absolute inset-0 border-4 border-pink-500/30 rounded-2xl heartbeat-pulse pointer-events-none" />
          )}

          {/* Hidden ReactPlayer */}
          {hasSong && (
            <div className="hidden">
              <ReactPlayer
                ref={playerRef}
                url={currentSong.url}
                playing={isPlaying}
                onProgress={handleProgress}
                onDuration={handleDuration}
                onEnded={handleSongEnd}
                controls={false}
                width="0"
                height="0"
              />
            </div>
          )}
        </div>

        {/* Track Info & Controls */}
        <div className="flex-1 w-full space-y-6 flex flex-col justify-center">
          <div className="text-center md:text-left">
            <h2 className="text-2xl sm:text-3xl font-bold text-white mb-2 leading-tight line-clamp-2">
              {currentSong?.title || 'Nothing playing'}
            </h2>
            <p className="text-zinc-400 text-lg line-clamp-1">{currentSong?.artist || 'Search and play a song'}</p>
          </div>

          {/* Progress Bar (Visual) */}
          <div className="space-y-2">
            <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-pink-500 to-purple-500 rounded-full transition-all duration-300"
                style={{ width: `${duration > 0 ? (progress / duration) * 100 : 0}%` }}
              />
            </div>
            <div className="flex justify-between text-xs font-medium text-zinc-500">
              <span>{formatTime(progress)}</span>
              <span>{currentSong?.durationText || formatTime(duration) || '0:00'}</span>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center md:justify-start gap-6">
            <button className="text-zinc-400 hover:text-white transition" disabled={!isHost || !hasSong}>
              <SkipBack className={`w-8 h-8 fill-current ${(!isHost || !hasSong) && 'opacity-50'}`} />
            </button>
            
            <button 
              onClick={togglePlay}
              disabled={!hasSong}
              className={`w-16 h-16 rounded-full flex items-center justify-center shadow-xl transition-all ${
                isHost && hasSong
                ? 'bg-white text-black hover:scale-105 active:scale-95 cursor-pointer' 
                : 'bg-white/20 text-white/50 cursor-not-allowed'
              }`}
            >
              {isPlaying ? <Pause className="w-8 h-8 fill-current" /> : <Play className="w-8 h-8 fill-current ml-1" />}
            </button>

            <button onClick={playNext} className="text-zinc-400 hover:text-white transition" disabled={!isHost || !hasSong}>
              <SkipForward className={`w-8 h-8 fill-current ${(!isHost || !hasSong) && 'opacity-50'}`} />
            </button>

            {/* Music Badge */}
            <div className="ml-auto hidden sm:flex items-center gap-2 px-3 py-1.5 bg-red-500/10 border border-red-500/20 rounded-full text-red-400 text-xs font-bold tracking-wide">
              <span>YT AUDIO</span>
            </div>
          </div>
          
          {!isHost && (
            <div className="text-xs text-center md:text-left text-zinc-500 font-medium pb-2">
              Waiting for host to control playback...
            </div>
          )}
        </div>
      </div>
      
      {/* Dynamic Tabs Section */}
      <div className="border-t border-white/10 flex bg-black/20 mt-8">
        <button 
          onClick={() => setActiveTab('player')} 
          className={`flex-1 py-3 text-sm font-medium transition-colors ${activeTab === 'player' ? 'text-pink-400 border-b-2 border-pink-400 bg-white/5' : 'text-zinc-400 hover:text-white'}`}
        >
          Now Playing
        </button>
        <button 
          onClick={() => setActiveTab('search')}
          className={`flex-1 py-3 text-sm font-medium transition-colors flex items-center justify-center gap-2 ${activeTab === 'search' ? 'text-pink-400 border-b-2 border-pink-400 bg-white/5' : 'text-zinc-400 hover:text-white'}`}
        >
          <Search className="w-4 h-4" /> Search
        </button>
        <button 
          onClick={() => setActiveTab('queue')}
          className={`flex-1 py-3 text-sm font-medium transition-colors flex items-center justify-center gap-2 ${activeTab === 'queue' ? 'text-pink-400 border-b-2 border-pink-400 bg-white/5' : 'text-zinc-400 hover:text-white'}`}
        >
          <ListMusic className="w-4 h-4" /> Queue
        </button>
        <button 
          onClick={() => setActiveTab('liked')}
          className={`flex-1 py-3 text-sm font-medium transition-colors flex items-center justify-center gap-2 ${activeTab === 'liked' ? 'text-pink-400 border-b-2 border-pink-400 bg-white/5' : 'text-zinc-400 hover:text-white'}`}
        >
          <HeartIcon className="w-4 h-4" /> Liked
        </button>
      </div>

      {/* Tab Contents */}
      <div className="p-6 bg-black/20 h-64 overflow-y-auto">
        {activeTab === 'player' && (
          <div className="flex flex-col items-center justify-center h-full text-center space-y-4">
            <div className="w-32 h-32 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center overflow-hidden">
               <Music className="w-12 h-12 text-zinc-600" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">No song playing</h3>
              <p className="text-sm text-zinc-400 mt-1">Select a song from Search or Queue</p>
            </div>
          </div>
        )}

        {activeTab === 'search' && (
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
              <input type="text" placeholder="Search Spotify..." className="w-full bg-black/50 border border-white/10 rounded-full pl-10 pr-4 py-2 text-sm text-white focus:outline-none focus:border-pink-500/50" />
            </div>
            <div className="text-center text-zinc-500 text-sm py-8">
              Search integration coming soon...
            </div>
          </div>
        )}

        {activeTab === 'queue' && (
          <div className="space-y-4">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">Up Next</h4>
            {room?.queue && room.queue.length > 0 ? (
              <div className="space-y-2">
                {room.queue.map((song, i) => renderSongItem(song, true, i))}
              </div>
            ) : (
              <div className="text-center text-zinc-500 text-sm py-8">
                Queue is empty
              </div>
            )}
          </div>
        )}

        {activeTab === 'liked' && (
          <div className="space-y-4">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <HeartIcon className="w-4 h-4 text-pink-500 fill-pink-500" /> Our Liked Songs
            </h4>
            {room?.favorites && room.favorites.length > 0 ? (
              <div className="space-y-2">
                {room.favorites.map((song, i) => renderSongItem(song, false, i))}
              </div>
            ) : (
              <div className="text-center text-zinc-500 text-sm py-8">
                No liked songs yet
              </div>
            )}
          </div>
        )}
      </div>

    </div>
  );
}
