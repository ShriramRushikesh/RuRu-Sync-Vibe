import React, { useEffect } from 'react';
import { useRoomStore } from '../store/useRoomStore';
import { motion, AnimatePresence } from 'framer-motion';

export default function LoveNotes() {
  const { loveNotes, emojis, removeLoveNote, removeEmoji } = useRoomStore();

  useEffect(() => {
    const intervals = emojis.map(emoji => {
      return setTimeout(() => removeEmoji(emoji.id), 4000);
    });
    return () => intervals.forEach(clearTimeout);
  }, [emojis, removeEmoji]);
  
  useEffect(() => {
    const intervals = loveNotes.map(note => {
      return setTimeout(() => removeLoveNote(note.id), 6000);
    });
    return () => intervals.forEach(clearTimeout);
  }, [loveNotes, removeLoveNote]);

  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
      <AnimatePresence>
        {emojis.map((em) => (
          <motion.div
            key={em.id}
            initial={{ y: '100vh', opacity: 0, x: `${em.x}vw`, scale: 0.5 }}
            animate={{ y: '-20vh', opacity: [0, 1, 1, 0], x: `${em.x + (Math.random() * 10 - 5)}vw`, scale: Math.random() * 1 + 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 4, ease: "easeOut" }}
            className="absolute text-4xl filter drop-shadow-md"
          >
            {em.emoji}
          </motion.div>
        ))}
        {loveNotes.map((note) => (
          <motion.div
            key={note.id}
            initial={{ opacity: 0, scale: 0.8, y: 50, x: `${Math.random() * 80 + 10}vw` }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.5, y: -50 }}
            transition={{ duration: 6, ease: "easeInOut" }}
            className="absolute p-4 floating bg-white/10 backdrop-blur-xl border border-pink-500/30 rounded-2xl shadow-2xl shadow-pink-500/20 max-w-xs"
            style={{ top: '20%' }}
          >
            <div className="flex items-center gap-2 mb-2 pb-2 border-b border-white/10">
              <span className="text-xs font-bold bg-pink-500 text-white px-2 py-0.5 rounded-full">{note.sender}</span>
              <span className="text-xs text-zinc-400">sent a love note</span>
            </div>
            <p className="text-pink-100 font-medium italic">"{note.message}"</p>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
