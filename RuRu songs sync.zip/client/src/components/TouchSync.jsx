import React, { useState, useEffect, useRef } from 'react';
import { useRoomStore } from '../store/useRoomStore';
import { motion, AnimatePresence } from 'framer-motion';
import { Fingerprint, Heart } from 'lucide-react';

export default function TouchSync() {
  const { socket, room, partnerTouching, setPartnerTouching } = useRoomStore();
  const [isTouching, setIsTouching] = useState(false);
  const [syncTime, setSyncTime] = useState(0);
  const intervalRef = useRef(null);

  useEffect(() => {
    if (!socket) return;
    socket.on('partner_touch_start', () => setPartnerTouching(true));
    socket.on('partner_touch_end', () => setPartnerTouching(false));
    
    return () => {
      socket.off('partner_touch_start');
      socket.off('partner_touch_end');
    };
  }, [socket, setPartnerTouching]);

  useEffect(() => {
    if (isTouching && partnerTouching) {
      intervalRef.current = setInterval(() => {
        setSyncTime(prev => prev + 1);
      }, 100);
    } else {
      clearInterval(intervalRef.current);
      setSyncTime(0);
    }
    return () => clearInterval(intervalRef.current);
  }, [isTouching, partnerTouching]);

  const handleTouchStart = () => {
    setIsTouching(true);
    socket.emit('touch_start');
    if (navigator.vibrate) navigator.vibrate(50);
  };

  const handleTouchEnd = () => {
    setIsTouching(false);
    socket.emit('touch_end');
  };

  const isSynced = isTouching && partnerTouching;
  const syncLevel = Math.min(syncTime / 20, 1); // Max after 2 seconds

  if (!room?.isCoupleMode) return null;

  return (
    <div className="relative bg-black/40 rounded-3xl border border-white/10 backdrop-blur-xl p-6 overflow-hidden mt-6 text-center">
      <h3 className="text-zinc-400 text-sm font-bold uppercase tracking-widest mb-4">Touch Sync</h3>
      
      <div className="relative flex justify-center items-center h-48">
        
        {/* Partner Indicator */}
        <AnimatePresence>
          {partnerTouching && (
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="absolute w-40 h-40 rounded-full bg-purple-500/20 blur-xl"
            />
          )}
        </AnimatePresence>

        {/* Sync Animation */}
        {isSynced && (
          <motion.div 
            className="absolute rounded-full border border-pink-500"
            style={{ width: 100 + syncLevel * 100, height: 100 + syncLevel * 100, opacity: 1 - syncLevel }}
            animate={{ scale: [1, 1.5], opacity: [0.8, 0] }}
            transition={{ repeat: Infinity, duration: 1 }}
          />
        )}

        {/* Touch Button */}
        <motion.button
          onMouseDown={handleTouchStart}
          onMouseUp={handleTouchEnd}
          onMouseLeave={handleTouchEnd}
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
          whileTap={{ scale: 0.95 }}
          className={`relative z-10 w-24 h-24 rounded-full flex items-center justify-center transition-all duration-500 ${
            isSynced ? 'bg-gradient-to-tr from-pink-500 to-purple-600 shadow-2xl shadow-pink-500/50' 
                     : isTouching ? 'bg-zinc-800 border-2 border-pink-500/50 text-pink-500' 
                     : 'bg-black/50 border border-white/10 text-zinc-500'
          }`}
        >
          {isSynced && syncLevel === 1 ? (
             <Heart className="w-10 h-10 text-white animate-bounce" fill="currentColor" />
          ) : (
             <Fingerprint className={`w-10 h-10 ${isSynced ? 'text-white' : ''}`} />
          )}
        </motion.button>
      </div>
      
      <div className="mt-4 text-sm font-medium h-6">
        {isSynced && syncLevel === 1 ? (
          <motion.span initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="text-pink-400 flex justify-center items-center gap-2">
            Connected ❤️
          </motion.span>
        ) : isTouching && !partnerTouching ? (
          <span className="text-zinc-400">Waiting for partner...</span>
        ) : partnerTouching && !isTouching ? (
          <span className="text-purple-400 animate-pulse">Partner is waiting!</span>
        ) : (
          <span className="text-zinc-600">Both touch & hold to sync</span>
        )}
      </div>
    </div>
  );
}
