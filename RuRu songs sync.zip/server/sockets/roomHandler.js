const rooms = {};

module.exports = (io, socket) => {
  const joinRoom = ({ roomId, username, isHost, isCoupleMode }) => {
    socket.join(roomId);
    
    if (!rooms[roomId]) {
      rooms[roomId] = {
        roomId,
        name: 'Vibes Room',
        hostSocketId: socket.id,
        isCoupleMode: isCoupleMode || false,
        users: [],
        currentSong: {
          uri: '', name: '', artist: '', durationMs: 0, progressMs: 0, isPlaying: false, updatedAt: Date.now()
        },
        queue: [],
        chatHistory: [],
        stats: { songsListened: 0, timeSpentMs: 0 },
        ourSongs: [],
        moodMode: 'normal'
      };
    } else {
      if (rooms[roomId].isCoupleMode && rooms[roomId].users.length >= 2) {
        socket.emit('error', { message: 'Couple mode room is full (max 2 users)' });
        return;
      }
    }

    const room = rooms[roomId];
    room.users.push({ socketId: socket.id, username, isHost });

    io.to(roomId).emit('room_update', room);
    
    // Heartbeat Sync
    socket.on('heartbeat', (data) => {
      socket.to(roomId).emit('partner_heartbeat', data);
    });

    // Touch Sync
    socket.on('touch_start', () => {
      socket.to(roomId).emit('partner_touch_start');
    });
    socket.on('touch_end', () => {
      socket.to(roomId).emit('partner_touch_end');
    });

    // Chat Ext
    socket.on('typing', (msg) => {
      socket.to(roomId).emit('partner_typing', msg);
    });

    // Chat
    socket.on('send_message', (message) => {
      room.chatHistory.push({ sender: username, message, timestamp: Date.now() });
      io.to(roomId).emit('receive_message', { sender: username, message, timestamp: Date.now() });
    });

    // Music Sync
    socket.on('player_state_change', (state) => {
      if (room.hostSocketId === socket.id) {
        room.currentSong = { ...state, updatedAt: Date.now() };
        socket.to(roomId).emit('sync_player', state);
      }
    });

    socket.on('sync_progress', (progress) => {
      // Allow host to send current time to keep clients in exact sync
      if (room.hostSocketId === socket.id) {
        room.currentSong.progressMs = progress;
        socket.to(roomId).emit('sync_progress', progress);
      }
    });

    // Queue Management
    socket.on('add_to_queue', (song) => {
      room.queue.push(song);
      io.to(roomId).emit('queue_updated', room.queue);
    });

    socket.on('play_next', () => {
      if (room.hostSocketId === socket.id) {
        if (room.queue.length > 0) {
          const nextSong = room.queue.shift();
          room.currentSong = { ...nextSong, isPlaying: true, progressMs: 0, updatedAt: Date.now() };
          io.to(roomId).emit('sync_player', room.currentSong);
          io.to(roomId).emit('queue_updated', room.queue);
        } else {
          // If queue is empty, just pause
          room.currentSong.isPlaying = false;
          io.to(roomId).emit('sync_player', room.currentSong);
        }
      }
    });

    socket.on('toggle_favorite', (song) => {
      if (!room.favorites) room.favorites = [];
      const exists = room.favorites.findIndex(s => s.videoId === song.videoId);
      if (exists !== -1) {
        room.favorites.splice(exists, 1);
      } else {
        room.favorites.push(song);
      }
      io.to(roomId).emit('favorites_updated', room.favorites);
    });

    // Love Notes
    socket.on('send_love_note', (note) => {
      io.to(roomId).emit('receive_love_note', { ...note, sender: username });
    });

    // Virtual Gifts
    socket.on('send_gift', (gift) => {
      io.to(roomId).emit('receive_gift', { ...gift, sender: username });
    });

    // Mood Lighting
    socket.on('change_mood', (mood) => {
      room.moodMode = mood;
      io.to(roomId).emit('mood_changed', mood);
    });

    // Memory Moments
    socket.on('save_moment', (moment) => {
      room.ourSongs.push({ ...moment, addedBy: username, timestamp: Date.now() });
      io.to(roomId).emit('moment_saved', moment);
    });

    // Voice Reactions
    socket.on('voice_reaction', (audioData) => {
      socket.to(roomId).emit('receive_voice_reaction', { audioData, sender: username });
    });
    
    // Emojis
    socket.on('send_emoji', (emojiData) => {
      io.to(roomId).emit('receive_emoji', emojiData);
    });
    
    // Playful commands
    socket.on('steal_attention', () => {
      socket.to(roomId).emit('attention_stolen');
    });

    socket.on('disconnect', () => {
      if (!rooms[roomId]) return;
      
      room.users = room.users.filter(u => u.socketId !== socket.id);
      
      if (room.users.length === 0) {
        delete rooms[roomId];
      } else {
        if (room.hostSocketId === socket.id && room.users.length > 0) {
          room.hostSocketId = room.users[0].socketId; // reassign host
          room.users[0].isHost = true;
        }
        io.to(roomId).emit('room_update', room);
      }
    });
  };

  socket.on('join_room', joinRoom);
};
